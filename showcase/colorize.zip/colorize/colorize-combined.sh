#!/bin/sh

if [ $# -le 2 ]; then
  echo "Usage:  colorize-combined.sh <input directory> <output directory> <color hexcode> ..."
  exit 0
fi

input_dir=$1; shift
if [ ! -d "$input_dir" ]; then
  echo "ERROR: Invalid input directory specified: $input_dir"
  exit 1
fi

output_dir=$1; shift
mkdir -p $output_dir

color_code=""
while [ -n "$1" ]; do
  color_code="$color_code $1"
  shift
done


mkdir -p $output_dir

for file in `ls -1 $input_dir 2>/dev/null`; do
  osascript ./colorize-combined.scpt $input_dir/$file $output_dir/$file $color_code
done
