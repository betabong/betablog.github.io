#!/bin/sh

if [ $# -le 2 ]; then
  echo "Usage:  colorize-in-psd.sh <input directory> <output directory> <color name:color hexcode> ..."
  exit 0
fi

input_dir=$1; shift
if [ ! -d "$input_dir" ]; then
  echo "ERROR: Invalid input directory specified: $input_dir"
  exit 1
fi

output_dir=$1; shift
mkdir -p $output_dir

while [ -n "$1" ]; do
  color_name=`echo $1 | cut -d\: -f1`
  color_code=`echo $1 | cut -d\: -f2 | sed 's/^#//g'`

  mkdir -p $output_dir/$color_name

  for file in `ls -1 $input_dir 2>/dev/null`; do
    osascript ./colorize-in-psd.scpt $input_dir/$file $color_code $output_dir/$color_name/$file
  done

  shift
done

